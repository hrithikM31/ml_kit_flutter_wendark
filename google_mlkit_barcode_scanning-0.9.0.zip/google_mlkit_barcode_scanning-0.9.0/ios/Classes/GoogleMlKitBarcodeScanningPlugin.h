#import <Flutter/Flutter.h>

@interface GoogleMlKitBarcodeScanningPlugin : NSObject<FlutterPlugin>
@end
